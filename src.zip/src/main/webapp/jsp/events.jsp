
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.sql.*" %>
<%@ page import="com.eventease.util.DBConnection" %>
<%@ page import="java.math.BigDecimal" %>

<%
    Connection con = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
%>

<!DOCTYPE html>
<html>
<head>
<title>EventEase - Explore Events</title>

<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: Arial, sans-serif;
    background: #f4f5fb;
    color: #1e293b;
}

.header {
    background: linear-gradient(120deg, #312e81, #6d28d9);
    color: white;
    padding: 30px 45px;
}

.header h1 {
    font-size: 30px;
    margin-bottom: 10px;
}

.header p {
    color: #ede9fe;
}

.back {
    display: inline-block;
    margin-top: 18px;
    color: white;
    text-decoration: none;
}

.container {
    max-width: 1200px;
    margin: 35px auto;
    padding: 0 25px;
}

.heading {
    margin-bottom: 25px;
}

.heading h2 {
    font-size: 25px;
    color: #312e81;
    margin-bottom: 8px;
}

.heading p {
    color: #64748b;
}

.events {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(270px, 1fr));
    gap: 24px;
}

.event-card {
    background: white;
    border-radius: 15px;
    padding: 25px;
    box-shadow: 0 5px 20px #0000000d;
    transition: 0.3s;
    border: 1px solid #eee;
}

.event-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 12px 25px #00000015;
}

.event-icon {
    font-size: 38px;
    margin-bottom: 18px;
}

.event-card h3 {
    color: #4c1d95;
    font-size: 21px;
    margin-bottom: 12px;
}

.description {
    color: #64748b;
    font-size: 14px;
    line-height: 1.6;
    min-height: 45px;
    margin-bottom: 18px;
}

.details {
    border-top: 1px solid #eee;
    padding-top: 15px;
    line-height: 2;
    font-size: 14px;
    color: #475569;
}

.price {
    color: #6d28d9;
    font-size: 19px;
    font-weight: bold;
    margin-top: 15px;
}

.book-btn {
    display: block;
    text-align: center;
    text-decoration: none;
    background: #6d28d9;
    color: white;
    padding: 12px;
    border-radius: 8px;
    margin-top: 18px;
    font-weight: bold;
}

.book-btn:hover {
    background: #4c1d95;
}

.empty {
    background: white;
    text-align: center;
    padding: 55px 20px;
    border-radius: 15px;
    color: #64748b;
}

.empty h3 {
    color: #312e81;
    margin: 15px 0 8px;
}

@media(max-width:600px) {
    .header {
        padding: 25px;
    }
}
</style>
</head>

<body>

<div class="header">
    <h1>✦ Explore Events</h1>
    <p>Discover exciting events and unforgettable experiences.</p>
    <a class="back" href="dashboard.jsp">← Back to Dashboard</a>
</div>

<div class="container">

    <div class="heading">
        <h2>Upcoming Events 🎉</h2>
        <p>Find your next favourite experience.</p>
    </div>

    <div class="events">

    <%
        try {
            con = DBConnection.getConnection();

            if (con != null) {
                String sql = "SELECT * FROM event WHERE event_date >= CURDATE() ORDER BY event_date ASC";
                ps = con.prepareStatement(sql);
                rs = ps.executeQuery();

                boolean found = false;

                while (rs.next()) {
                    found = true;

                    int id = rs.getInt("event_id");
                    String name = rs.getString("event_name");
                    String description = rs.getString("description");
                    Date date = rs.getDate("event_date");
                    Time time = rs.getTime("event_time");
                    String venue = rs.getString("venue");
                    BigDecimal price = rs.getBigDecimal("price");
                    int seats = rs.getInt("available_seats");

                    if (description == null || description.trim().isEmpty()) {
                        description = "Join us for an amazing experience!";
                    }
    %>

        <div class="event-card">

            <div class="event-icon">🎊</div>

            <h3><%= name %></h3>

            <p class="description"><%= description %></p>

            <div class="details">
                📅 <strong>Date:</strong> <%= date %><br>
                🕒 <strong>Time:</strong>
                <%= time == null ? "To be announced" : time %><br>
                📍 <strong>Venue:</strong> <%= venue %><br>
                🎟️ <strong>Available Seats:</strong> <%= seats %>
            </div>

            <div class="price">
                <%= price == null || price.compareTo(BigDecimal.ZERO) == 0
                    ? "Free Entry" : "₹" + price %>
            </div>
<a class="book-btn"
   href="${pageContext.request.contextPath}/book-event?event_id=<%= id %>">
   Book Now
</a>

        </div>

    <%
                }

                if (!found) {
    %>
        <div class="empty">
            <div style="font-size:45px;">🎭</div>
            <h3>No Upcoming Events</h3>
            <p>New exciting events will be available soon!</p>
        </div>
    <%
                }
            } else {
    %>
        <p>Database connection failed!</p>
    <%
            }

        } catch (Exception e) {
            out.println("<p>Unable to load events: " + e.getMessage() + "</p>");
            e.printStackTrace();
        } finally {
            try { if (rs != null) rs.close(); } catch (Exception e) {}
            try { if (ps != null) ps.close(); } catch (Exception e) {}
            try { if (con != null) con.close(); } catch (Exception e) {}
        }
    %>

    </div>
</div>

</body>
</html>
