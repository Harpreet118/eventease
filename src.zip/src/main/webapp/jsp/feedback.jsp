
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.sql.*" %>
<%@ page import="com.eventease.util.DBConnection" %>

<%
    if (session.getAttribute("user_id") == null) {
        response.sendRedirect(request.getContextPath() + "/jsp/login.jsp");
        return;
    }

    int userId = (Integer) session.getAttribute("user_id");
    Connection con = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
%>

<!DOCTYPE html>
<html>
<head>
<title>EventEase - Feedback</title>

<style>
* { margin:0; padding:0; box-sizing:border-box; }

body {
    font-family:Arial,sans-serif;
    background:#f4f5fb;
    min-height:100vh;
}

.header {
    background:linear-gradient(120deg,#312e81,#6d28d9);
    color:white;
    padding:28px 45px;
}

.header h1 { margin-bottom:8px; }
.header p { color:#ede9fe; }

.back {
    display:inline-block;
    color:white;
    text-decoration:none;
    margin-top:15px;
}

.container {
    max-width:650px;
    margin:40px auto;
    padding:0 20px;
}

.form-box {
    background:white;
    padding:35px;
    border-radius:18px;
    box-shadow:0 8px 30px #00000010;
}

.form-box h2 {
    color:#4c1d95;
    margin-bottom:10px;
}

.subtitle {
    color:#64748b;
    margin-bottom:25px;
}

label {
    display:block;
    color:#334155;
    font-weight:bold;
    margin:18px 0 9px;
}

select, textarea {
    width:100%;
    padding:13px;
    border:1px solid #cbd5e1;
    border-radius:8px;
    font-size:15px;
}

textarea {
    height:120px;
    resize:vertical;
}

.rating {
    display:flex;
    gap:12px;
    margin-top:12px;
}

.rating input { display:none; }

.rating label {
    font-size:32px;
    color:#cbd5e1;
    cursor:pointer;
    margin:0;
}

.rating label:has(input:checked),
.rating label:has(input:checked) ~ label {
    color:#f59e0b;
}

button {
    width:100%;
    padding:14px;
    margin-top:25px;
    border:none;
    border-radius:8px;
    background:#6d28d9;
    color:white;
    font-size:16px;
    font-weight:bold;
    cursor:pointer;
}

button:hover { background:#4c1d95; }

</style>
</head>

<body>

<div class="header">
    <h1>⭐ Share Your Feedback</h1>
    <p>Your experience matters to us!</p>
    <a class="back" href="dashboard.jsp">← Back to Dashboard</a>
</div>

<div class="container">

<div class="form-box">

    <h2>We value your opinion!</h2>
    <p class="subtitle">Tell us about your event experience.</p>

    <form action="${pageContext.request.contextPath}/submit-feedback"
          method="post">

        <label>Select Event</label>

        <select name="event_id" required>
            <option value="">-- Choose an Event --</option>

            <%
                try {
                    con = DBConnection.getConnection();

                    String sql =
                        "SELECT DISTINCT e.event_id, e.event_name "
                        + "FROM event e "
                        + "JOIN registrations r ON e.event_id = r.event_id "
                        + "WHERE r.user_id = ? AND r.status = 'Confirmed'";

                    ps = con.prepareStatement(sql);
                    ps.setInt(1, userId);
                    rs = ps.executeQuery();

                    while (rs.next()) {
            %>

            <option value="<%= rs.getInt("event_id") %>">
                <%= rs.getString("event_name") %>
            </option>

            <%
                    }
                } catch (Exception e) {
                    out.println("<option value=''>Unable to load events</option>");
                    e.printStackTrace();
                } finally {
                    try { if (rs != null) rs.close(); } catch (Exception e) {}
                    try { if (ps != null) ps.close(); } catch (Exception e) {}
                    try { if (con != null) con.close(); } catch (Exception e) {}
                }
            %>

        </select>

        <label>Rate Your Experience</label>

        <div class="rating">
            <label><input type="radio" name="rating" value="1" required>⭐</label>
            <label><input type="radio" name="rating" value="2">⭐</label>
            <label><input type="radio" name="rating" value="3">⭐</label>
            <label><input type="radio" name="rating" value="4">⭐</label>
            <label><input type="radio" name="rating" value="5">⭐</label>
        </div>

        <label>Write Your Feedback</label>

        <textarea name="feedback_text"
                  placeholder="Share your experience..."
                  required></textarea>

        <button type="submit">Submit Feedback</button>

    </form>

</div>
</div>

</body>
</html>
