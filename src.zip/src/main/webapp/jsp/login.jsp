
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <title>EventEase - Login</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #0f172a, #312e81, #6d28d9);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .login-box {
            width: 380px;
            background: white;
            padding: 38px;
            border-radius: 18px;
            box-shadow: 0 15px 40px rgba(0,0,0,0.3);
        }

        .logo {
            text-align: center;
            color: #6d28d9;
            font-size: 30px;
            font-weight: bold;
        }

        h2 {
            text-align: center;
            color: #1e293b;
            margin-bottom: 8px;
        }

        .subtitle {
            text-align: center;
            color: #64748b;
            margin-bottom: 28px;
        }

        label {
            display: block;
            margin-top: 15px;
            color: #334155;
            font-weight: bold;
        }

        input {
            width: 100%;
            padding: 13px;
            margin-top: 8px;
            border: 1px solid #cbd5e1;
            border-radius: 8px;
            outline: none;
        }

        input:focus {
            border-color: #7c3aed;
        }

        button {
            width: 100%;
            padding: 14px;
            margin-top: 25px;
            background: #6d28d9;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background: #4c1d95;
        }

        .register {
            text-align: center;
            margin-top: 22px;
            color: #64748b;
        }

        a {
            color: #6d28d9;
            text-decoration: none;
            font-weight: bold;
        }

        .error {
            color: #dc2626;
            text-align: center;
            margin-top: 12px;
        }
    </style>
</head>

<body>

<div class="login-box">

    <div class="logo">EventEase</div>

    <h2>Welcome Back!</h2>
    <p class="subtitle">Login to manage your events</p>

    <form action="${pageContext.request.contextPath}/login" method="post">

        <label>Email Address</label>
        <input type="email" name="email"
               placeholder="Enter your email" required>

        <label>Password</label>
        <input type="password" name="password"
               placeholder="Enter your password" required>

        <button type="submit">Login</button>

    </form>

    <% if ("1".equals(request.getParameter("error"))) { %>
        <p class="error">Invalid email or password!</p>
    <% } %>

    <div class="register">
        Don't have an account?
        <a href="${pageContext.request.contextPath}/jsp/register.jsp">
            Register
        </a>
    </div>

</div>

</body>
</html>
