
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <title>EventEase - Add Event</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background: #f4f5fb;
            padding: 35px 15px;
        }

        .container {
            max-width: 650px;
            margin: auto;
            background: white;
            padding: 35px;
            border-radius: 18px;
            box-shadow: 0 8px 30px #00000012;
        }

        h1 {
            color: #4c1d95;
            margin-bottom: 10px;
        }

        .subtitle {
            color: #64748b;
            margin-bottom: 28px;
        }

        label {
            display: block;
            margin: 17px 0 8px;
            font-weight: bold;
            color: #334155;
        }

        input, textarea {
            width: 100%;
            padding: 13px;
            border: 1px solid #cbd5e1;
            border-radius: 8px;
            font-size: 15px;
        }

        textarea {
            height: 100px;
            resize: vertical;
        }

        .row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }

        button {
            width: 100%;
            padding: 14px;
            margin-top: 25px;
            border: none;
            border-radius: 8px;
            background: #6d28d9;
            color: white;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
        }

        button:hover {
            background: #4c1d95;
        }

        .back {
            display: inline-block;
            margin-bottom: 22px;
            color: #6d28d9;
            text-decoration: none;
        }

        @media(max-width: 550px) {
            .row {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>

<body>

<div class="container">

    <a class="back" href="dashboard.jsp">← Back to Dashboard</a>

    <h1>＋ Add New Event</h1>
    <p class="subtitle">Enter the details to create an event.</p>

    <form action="${pageContext.request.contextPath}/add-event"
          method="post">

        <label>Event Name</label>
        <input type="text" name="event_name"
               placeholder="Enter event name" required>

        <label>Description</label>
        <textarea name="description"
                  placeholder="Describe your event"></textarea>

        <div class="row">
            <div>
                <label>Event Date</label>
                <input type="date" name="event_date" required>
            </div>

            <div>
                <label>Event Time</label>
                <input type="time" name="event_time">
            </div>
        </div>

        <label>Venue</label>
        <input type="text" name="venue"
               placeholder="Enter event venue" required>

        <div class="row">
            <div>
                <label>Ticket Price (₹)</label>
                <input type="number" name="price"
                       min="0" step="0.01" placeholder="0.00">
            </div>

            <div>
                <label>Total Seats</label>
                <input type="number" name="total_seats"
                       min="1" placeholder="100" required>
            </div>
        </div>

        <button type="submit">Create Event</button>

    </form>

</div>

</body>
</html>
