
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.sql.*" %>
<%@ page import="com.eventease.util.DBConnection" %>

<%
    if (session.getAttribute("user_id") == null) {
        response.sendRedirect(request.getContextPath() + "/jsp/login.jsp");
        return;
    }

    String name = (String) session.getAttribute("full_name");
    String role = (String) session.getAttribute("role");

    if (name == null) name = "User";
    if (role == null) role = "user";

    int totalEvents = 0;
    int totalBookings = 0;
    int totalFeedback = 0;

    int userId = (Integer) session.getAttribute("user_id");

    try (Connection con = DBConnection.getConnection()) {

        if (con != null) {

            try (PreparedStatement ps = con.prepareStatement(
                    "SELECT COUNT(*) FROM event WHERE event_date >= CURDATE()");
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next()) totalEvents = rs.getInt(1);
            }

            try (PreparedStatement ps = con.prepareStatement(
                    "SELECT COUNT(*) FROM registrations WHERE user_id = ?")) {
                ps.setInt(1, userId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) totalBookings = rs.getInt(1);
                }
            }

            try (PreparedStatement ps = con.prepareStatement(
                    "SELECT COUNT(*) FROM event_feedback WHERE user_id = ?")) {
                ps.setInt(1, userId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) totalFeedback = rs.getInt(1);
                }
            }
        }

    } catch (Exception e) {
        e.printStackTrace();
    }
%>

<!DOCTYPE html>
<html>
<head>
    <title>EventEase - Dashboard</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background: #f4f5fb;
            color: #1e293b;
        }

        .sidebar {
            width: 245px;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            background: #111827;
            color: white;
            padding: 28px 20px;
        }

        .logo {
            font-size: 27px;
            font-weight: bold;
            color: #c4b5fd;
            margin-bottom: 45px;
        }

        .nav a {
            display: block;
            color: #cbd5e1;
            text-decoration: none;
            padding: 14px;
            margin: 9px 0;
            border-radius: 9px;
            transition: 0.3s;
        }

        .nav a:hover,
        .nav a.active {
            background: #6d28d9;
            color: white;
            transform: translateX(4px);
        }

        .main {
            margin-left: 245px;
            padding: 30px 40px;
        }

        .topbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 35px;
            gap: 15px;
        }

        .topbar p {
            color: #64748b;
            margin-top: 5px;
        }

        .profile {
            background: white;
            padding: 12px 20px;
            border-radius: 30px;
            box-shadow: 0 3px 12px #0000000d;
            font-weight: bold;
        }

        .welcome {
            background: linear-gradient(120deg, #4c1d95, #7c3aed, #a78bfa);
            color: white;
            padding: 38px;
            border-radius: 18px;
            margin-bottom: 30px;
            box-shadow: 0 8px 25px #6d28d933;
        }

        .welcome h1 {
            font-size: 30px;
            margin-bottom: 12px;
        }

        .welcome p {
            color: #ede9fe;
            line-height: 1.7;
        }

        .section-title {
            margin: 28px 0 18px;
            color: #1e293b;
        }

        .stats {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            padding: 23px;
            border-radius: 15px;
            box-shadow: 0 4px 15px #0000000a;
            border-left: 5px solid #7c3aed;
        }

        .stat-card .number {
            font-size: 29px;
            font-weight: bold;
            color: #6d28d9;
            margin-top: 12px;
        }

        .stat-card p {
            color: #64748b;
            margin-top: 7px;
        }

        .cards {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
        }

        .card-link {
            text-decoration: none;
            color: inherit;
        }

        .card {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 4px 15px #0000000a;
            height: 100%;
            transition: 0.3s;
        }

        .card:hover {
            transform: translateY(-6px);
            box-shadow: 0 10px 25px #00000015;
        }

        .card .emoji {
            font-size: 32px;
            margin-bottom: 15px;
        }

        .card h3 {
            margin-bottom: 9px;
            color: #312e81;
        }

        .card p {
            color: #64748b;
            line-height: 1.6;
            font-size: 14px;
        }

        .event-list {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 18px;
        }

        .event-box {
            background: white;
            padding: 23px;
            border-radius: 14px;
            box-shadow: 0 4px 15px #0000000a;
        }

        .event-box h3 {
            color: #4c1d95;
            margin-bottom: 12px;
        }

        .event-box p {
            color: #64748b;
            font-size: 14px;
            line-height: 1.7;
        }

        .event-price {
            color: #6d28d9;
            font-weight: bold;
            margin-top: 12px;
        }

        .view-btn {
            display: inline-block;
            margin-top: 14px;
            padding: 9px 16px;
            background: #6d28d9;
            color: white;
            border-radius: 7px;
            text-decoration: none;
            font-size: 13px;
        }

        .empty {
            background: white;
            padding: 30px;
            border-radius: 14px;
            text-align: center;
            color: #64748b;
            grid-column: 1 / -1;
        }

        @media(max-width: 950px) {
            .stats, .cards {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media(max-width: 850px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }

            .logo {
                margin-bottom: 15px;
            }

            .nav {
                display: flex;
                flex-wrap: wrap;
            }

            .main {
                margin-left: 0;
                padding: 20px;
            }

            .stats, .cards, .event-list {
                grid-template-columns: 1fr;
            }

            .topbar {
                align-items: flex-start;
                flex-direction: column;
            }
        }
    </style>
</head>

<body>

<div class="sidebar">

    <div class="logo">✦ EventEase</div>

    <div class="nav">

        <a href="${pageContext.request.contextPath}/jsp/dashboard.jsp"
           class="active">⌂ Dashboard</a>

        <% if ("admin".equalsIgnoreCase(role)) { %>
            <a href="${pageContext.request.contextPath}/jsp/add-event.jsp">
                ＋ Add Event
            </a>
        <% } %>

        <a href="${pageContext.request.contextPath}/jsp/events.jsp">
            ▣ Explore Events
        </a>

        <a href="${pageContext.request.contextPath}/jsp/my-bookings.jsp">
            ▤ My Bookings
        </a>

        <a href="${pageContext.request.contextPath}/jsp/feedback.jsp">
            ☆ Feedback
        </a>

    </div>
</div>

<div class="main">

    <div class="topbar">

        <div>
            <h2>Dashboard</h2>
            <p>Your EventEase management space</p>
        </div>

        <div class="profile">
            👤 <%= name %>
        </div>

    </div>

    <div class="welcome">

        <h1>Welcome, <%= name %>! 👋</h1>

        <p>
            Discover exciting events, book your favourite experiences
            and manage all your bookings in one place.
        </p>

    </div>

    <h2 class="section-title">Your Overview</h2>

    <div class="stats">

        <div class="stat-card">
            <div style="font-size:28px;">🎉</div>
            <div class="number"><%= totalEvents %></div>
            <p>Upcoming Events</p>
        </div>

        <div class="stat-card">
            <div style="font-size:28px;">🎟️</div>
            <div class="number"><%= totalBookings %></div>
            <p>My Bookings</p>
        </div>

        <div class="stat-card">
            <div style="font-size:28px;">⭐</div>
            <div class="number"><%= totalFeedback %></div>
            <p>Feedback Submitted</p>
        </div>

    </div>

    <h2 class="section-title">Quick Access</h2>

    <div class="cards">

        <a class="card-link"
           href="${pageContext.request.contextPath}/jsp/events.jsp">

            <div class="card">
                <div class="emoji">🎉</div>
                <h3>Explore Events</h3>
                <p>Discover upcoming events and exciting experiences.</p>
            </div>

        </a>

        <a class="card-link"
           href="${pageContext.request.contextPath}/jsp/my-bookings.jsp">

            <div class="card">
                <div class="emoji">🎟️</div>
                <h3>My Bookings</h3>
                <p>View and manage all your event registrations.</p>
            </div>

        </a>

        <a class="card-link"
           href="${pageContext.request.contextPath}/jsp/feedback.jsp">

            <div class="card">
                <div class="emoji">⭐</div>
                <h3>Share Feedback</h3>
                <p>Share your experience and help us improve.</p>
            </div>

        </a>

    </div>

    <h2 class="section-title">Upcoming Events</h2>

    <div class="event-list">

        <%
            try (Connection con = DBConnection.getConnection()) {

                if (con != null) {

                    String sql =
                        "SELECT event_id, event_name, description, "
                        + "event_date, event_time, venue, price "
                        + "FROM event WHERE event_date >= CURDATE() "
                        + "ORDER BY event_date ASC LIMIT 4";

                    try (PreparedStatement ps = con.prepareStatement(sql);
                         ResultSet rs = ps.executeQuery()) {

                        boolean found = false;

                        while (rs.next()) {
                            found = true;
        %>

        <div class="event-box">

            <h3>🎭 <%= rs.getString("event_name") %></h3>

            <p>
                📅 <strong>Date:</strong>
                <%= rs.getDate("event_date") %>
                <br>

                🕒 <strong>Time:</strong>
                <%= rs.getTime("event_time") == null
                    ? "To be announced"
                    : rs.getTime("event_time") %>
                <br>

                📍 <strong>Venue:</strong>
                <%= rs.getString("venue") %>
            </p>

            <p class="event-price">
                Price: ₹<%= rs.getBigDecimal("price") == null
                    ? "0.00"
                    : rs.getBigDecimal("price") %>
            </p>

            <a class="view-btn"
               href="${pageContext.request.contextPath}/jsp/events.jsp">
                View Events
            </a>

        </div>

        <%
                        }

                        if (!found) {
        %>

        <div class="empty">
            <h3>No Upcoming Events Yet!</h3>
            <p>New events will appear here when they are added.</p>
        </div>

        <%
                        }
                    }

                } else {
        %>

        <div class="empty">
            Unable to connect to the database.
        </div>

        <%
                }

            } catch (Exception e) {
                e.printStackTrace();
        %>

        <div class="empty">
            Unable to load upcoming events.
        </div>

        <%
            }
        %>

    </div>

</div>

</body>
</html>
