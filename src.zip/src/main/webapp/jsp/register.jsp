
<!DOCTYPE html>
<html>
<head>
    <title>EventEase - User Registration</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f1f5f9;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .container {
            background: white;
            padding: 30px;
            width: 350px;
            border-radius: 12px;
            box-shadow: 0 4px 15px #0002;
        }

        h2 {
            text-align: center;
            color: #4f46e5;
        }

        input {
            width: 100%;
            padding: 11px;
            margin: 9px 0;
            box-sizing: border-box;
        }

        button {
            width: 100%;
            padding: 12px;
            background: #4f46e5;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 6px;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>EventEase Registration</h2>

    <form action="${pageContext.request.contextPath}/register" method="post">

        <input type="text" name="full_name"
               placeholder="Full Name" required>

        <input type="email" name="email"
               placeholder="Email Address" required>

        <input type="password" name="password"
               placeholder="Password" required>

        <input type="text" name="phone"
               placeholder="Phone Number">

        <button type="submit">Create Account</button>

    </form>
</div>

</body>
</html>
