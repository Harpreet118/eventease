
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.sql.*" %>
<%@ page import="com.eventease.util.DBConnection" %>
<%@ page import="java.math.BigDecimal" %>

<%
    if (session.getAttribute("user_id") == null) {
        response.sendRedirect(request.getContextPath() + "/jsp/login.jsp");
        return;
    }

    int userId = (Integer) session.getAttribute("user_id");
    Connection con = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    boolean found = false;
%>

<!DOCTYPE html>
<html>
<head>
<title>EventEase - My Bookings</title>

<style>
* { margin:0; padding:0; box-sizing:border-box; }

body {
    font-family:Arial,sans-serif;
    background:#f4f5fb;
    color:#1e293b;
}

.header {
    background:linear-gradient(120deg,#312e81,#6d28d9);
    color:white;
    padding:30px 45px;
}

.header h1 { margin-bottom:10px; }

.header p { color:#ede9fe; }

.back {
    display:inline-block;
    color:white;
    text-decoration:none;
    margin-top:18px;
}

.container {
    max-width:1100px;
    margin:35px auto;
    padding:0 25px;
}

.container h2 {
    color:#312e81;
    margin-bottom:25px;
}

.booking-card {
    background:white;
    padding:25px;
    border-radius:14px;
    margin-bottom:20px;
    box-shadow:0 5px 18px #0000000d;
    border-left:5px solid #7c3aed;
}

.booking-card h3 {
    color:#4c1d95;
    margin-bottom:15px;
}

.details {
    color:#475569;
    line-height:2;
    font-size:14px;
}

.status {
    display:inline-block;
    background:#dcfce7;
    color:#15803d;
    padding:6px 13px;
    border-radius:20px;
    font-weight:bold;
    margin-top:12px;
    font-size:13px;
}

.amount {
    color:#6d28d9;
    font-weight:bold;
    font-size:19px;
    margin-top:12px;
}

.empty {
    background:white;
    text-align:center;
    padding:55px 20px;
    border-radius:15px;
    color:#64748b;
}

.empty h3 {
    color:#312e81;
    margin:15px 0;
}

.explore {
    display:inline-block;
    background:#6d28d9;
    color:white;
    text-decoration:none;
    padding:12px 22px;
    border-radius:8px;
    margin-top:20px;
}
</style>
</head>

<body>

<div class="header">
    <h1>🎟️ My Bookings</h1>
    <p>Manage and view all your event bookings.</p>
    <a class="back" href="dashboard.jsp">← Back to Dashboard</a>
</div>

<div class="container">

<h2>Your Booking History</h2>

<%
    try {
        con = DBConnection.getConnection();

        String sql =
            "SELECT r.registration_id, r.registration_date, "
            + "r.number_of_tickets, r.total_amount, r.status, "
            + "e.event_name, e.event_date, e.event_time, e.venue "
            + "FROM registrations r "
            + "JOIN event e ON r.event_id = e.event_id "
            + "WHERE r.user_id = ? "
            + "ORDER BY r.registration_id DESC";

        ps = con.prepareStatement(sql);
        ps.setInt(1, userId);
        rs = ps.executeQuery();

        while (rs.next()) {
            found = true;

            String eventName = rs.getString("event_name");
            Date eventDate = rs.getDate("event_date");
            Time eventTime = rs.getTime("event_time");
            String venue = rs.getString("venue");
            int tickets = rs.getInt("number_of_tickets");
            BigDecimal amount = rs.getBigDecimal("total_amount");
            String status = rs.getString("status");
%>

<div class="booking-card">

    <h3>🎉 <%= eventName %></h3>

    <div class="details">
        📅 <strong>Event Date:</strong> <%= eventDate %><br>
        🕒 <strong>Event Time:</strong>
        <%= eventTime == null ? "To be announced" : eventTime %><br>
        📍 <strong>Venue:</strong> <%= venue %><br>
        🎟️ <strong>Tickets:</strong> <%= tickets %><br>
        🧾 <strong>Booking Date:</strong>
        <%= rs.getTimestamp("registration_date") %>
    </div>

    <div class="amount">
        Total Amount: ₹<%= amount %>
    </div>

    <span class="status"><%= status %></span>

</div>

<%
        }

        if (!found) {
%>

<div class="empty">
    <div style="font-size:45px;">🎫</div>
    <h3>No Bookings Yet!</h3>
    <p>You haven't booked any events. Explore events to get started.</p>
    <a class="explore" href="events.jsp">Explore Events</a>
</div>

<%
        }

    } catch (Exception e) {
        out.println("<p>Unable to load bookings: " + e.getMessage() + "</p>");
        e.printStackTrace();
    } finally {
        try { if (rs != null) rs.close(); } catch (Exception e) {}
        try { if (ps != null) ps.close(); } catch (Exception e) {}
        try { if (con != null) con.close(); } catch (Exception e) {}
    }
%>

</div>
</body>
</html>
