<%
    response.sendRedirect(
        request.getContextPath() + "/jsp/dashboard.jsp"
    );
%>