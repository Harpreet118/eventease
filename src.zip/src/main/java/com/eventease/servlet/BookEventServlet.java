
package com.eventease.servlet;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.eventease.util.DBConnection;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/book-event")
public class BookEventServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        // Check whether user is logged in
        if (session == null || session.getAttribute("user_id") == null) {
            response.sendRedirect(
                request.getContextPath() + "/jsp/login.jsp");
            return;
        }

        int userId = (Integer) session.getAttribute("user_id");

        int eventId;

        try {
            eventId = Integer.parseInt(
                request.getParameter("event_id"));
        } catch (Exception e) {
            response.sendRedirect(
                request.getContextPath() + "/jsp/events.jsp");
            return;
        }

        String message = "";

        try (Connection con = DBConnection.getConnection()) {

            if (con == null) {
                throw new Exception("Database connection failed!");
            }

            con.setAutoCommit(false);

            try {
                String checkSql =
                    "SELECT price, available_seats FROM event "
                    + "WHERE event_id = ? FOR UPDATE";

                BigDecimal price;
                int seats;

                try (PreparedStatement ps = con.prepareStatement(checkSql)) {
                    ps.setInt(1, eventId);

                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) {
                            throw new Exception("Event not found!");
                        }

                        seats = rs.getInt("available_seats");
                        price = rs.getBigDecimal("price");

                        if (price == null) {
                            price = BigDecimal.ZERO;
                        }
                    }
                }

                if (seats <= 0) {
                    throw new Exception("Sorry! No seats available.");
                }

                String insertSql =
                    "INSERT INTO registrations "
                    + "(user_id, event_id, registration_date, "
                    + "number_of_tickets, total_amount, status) "
                    + "VALUES (?, ?, NOW(), 1, ?, ?)";

                try (PreparedStatement ps = con.prepareStatement(insertSql)) {
                    ps.setInt(1, userId);
                    ps.setInt(2, eventId);
                    ps.setBigDecimal(3, price);
                    ps.setString(4, "Confirmed");
                    ps.executeUpdate();
                }

                String updateSql =
                    "UPDATE event SET available_seats = "
                    + "available_seats - 1 WHERE event_id = ?";

                try (PreparedStatement ps = con.prepareStatement(updateSql)) {
                    ps.setInt(1, eventId);
                    ps.executeUpdate();
                }

                con.commit();
                message = "Booking Confirmed Successfully!";

            } catch (Exception e) {
                con.rollback();
                throw e;
            }

        } catch (Exception e) {
            e.printStackTrace();
            message = e.getMessage();
        }

        response.setContentType("text/html;charset=UTF-8");

        response.getWriter().println(
            "<html><body style='font-family:Arial;text-align:center;"
            + "padding:60px;background:#f4f5fb;'>"
            + "<h1 style='color:#6d28d9;'>EventEase</h1>"
            + "<h2>" + message + "</h2>"
            + "<a href='" + request.getContextPath()
            + "/jsp/events.jsp'>Explore More Events</a>"
            + "</body></html>");
    }
}
