
package com.eventease.servlet;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Date;
import java.sql.Time;

import com.eventease.util.DBConnection;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/add-event")
public class AddEventServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        String eventName = request.getParameter("event_name");
        String description = request.getParameter("description");
        String eventDate = request.getParameter("event_date");
        String eventTime = request.getParameter("event_time");
        String venue = request.getParameter("venue");
        String price = request.getParameter("price");
        String seats = request.getParameter("total_seats");

        String sql = "INSERT INTO event "
                + "(event_name, description, event_date, event_time, "
                + "venue, price, total_seats, available_seats) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        response.setContentType("text/html;charset=UTF-8");

        try (Connection con = DBConnection.getConnection()) {

            if (con == null) {
                response.getWriter().println("Database connection failed!");
                return;
            }

            try (PreparedStatement ps = con.prepareStatement(sql)) {

                int totalSeats = Integer.parseInt(seats);

                ps.setString(1, eventName);
                ps.setString(2, description);
                ps.setDate(3, Date.valueOf(eventDate));

                if (eventTime == null || eventTime.isEmpty()) {
                    ps.setNull(4, java.sql.Types.TIME);
                } else {
                    ps.setTime(4, Time.valueOf(eventTime + ":00"));
                }

                ps.setString(5, venue);

                if (price == null || price.isEmpty()) {
                    ps.setNull(6, java.sql.Types.DECIMAL);
                } else {
                    ps.setBigDecimal(6, new BigDecimal(price));
                }

                ps.setInt(7, totalSeats);
                ps.setInt(8, totalSeats);

                int result = ps.executeUpdate();

                if (result > 0) {
                    response.getWriter().println(
                        "<h2>Event Added Successfully!</h2>"
                    );
                    response.getWriter().println(
                        "<a href='" + request.getContextPath()
                        + "/jsp/add-event.jsp'>Add Another Event</a><br>"
                    );
                    response.getWriter().println(
                        "<a href='" + request.getContextPath()
                        + "/jsp/dashboard.jsp'>Dashboard</a>"
                    );
                } else {
                    response.getWriter().println("Event could not be added!");
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println(
                "Error while adding event: " + e.getMessage()
            );
        }
    }
}
