
package com.eventease.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.eventease.util.DBConnection;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/submit-feedback")
public class SubmitFeedbackServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");

        HttpSession session = request.getSession(false);

        if (session == null || session.getAttribute("user_id") == null) {
            response.sendRedirect(
                request.getContextPath() + "/jsp/login.jsp");
            return;
        }

        int userId = (Integer) session.getAttribute("user_id");

        try {
            int eventId = Integer.parseInt(
                request.getParameter("event_id"));

            int rating = Integer.parseInt(
                request.getParameter("rating"));

            String feedbackText =
                request.getParameter("feedback_text");

            if (rating < 1 || rating > 5 ||
                    feedbackText == null || feedbackText.trim().isEmpty()) {
                response.getWriter().println("Please enter valid feedback.");
                return;
            }

            try (Connection con = DBConnection.getConnection()) {

                if (con == null) {
                    throw new Exception("Database connection failed!");
                }

                // Verify that the user has booked this event
                String checkSql =
                    "SELECT registration_id FROM registrations "
                    + "WHERE user_id = ? AND event_id = ? "
                    + "AND status = 'Confirmed' LIMIT 1";

                try (PreparedStatement check =
                        con.prepareStatement(checkSql)) {

                    check.setInt(1, userId);
                    check.setInt(2, eventId);

                    try (ResultSet rs = check.executeQuery()) {

                        if (!rs.next()) {
                            response.getWriter().println(
                                "<h2>You must book this event before submitting feedback.</h2>");
                            return;
                        }
                    }
                }

                String sql =
                    "INSERT INTO event_feedback "
                    + "(user_id, event_id, rating, feedback_text) "
                    + "VALUES (?, ?, ?, ?)";

                try (PreparedStatement ps = con.prepareStatement(sql)) {

                    ps.setInt(1, userId);
                    ps.setInt(2, eventId);
                    ps.setInt(3, rating);
                    ps.setString(4, feedbackText.trim());

                    int result = ps.executeUpdate();

                    if (result > 0) {
                        response.getWriter().println(
                            "<div style='text-align:center;font-family:Arial;padding:60px;'>"
                            + "<h1 style='color:#6d28d9;'>EventEase ⭐</h1>"
                            + "<h2>Feedback Submitted Successfully!</h2>"
                            + "<p>Thank you for sharing your experience.</p>"
                            + "<a href='" + request.getContextPath()
                            + "/jsp/dashboard.jsp'>Back to Dashboard</a>"
                            + "</div>");
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println(
                "<h2>Unable to submit feedback: "
                + e.getMessage() + "</h2>");
        }
    }
}
