
package com.eventease.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.eventease.util.DBConnection;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        response.sendRedirect(
            request.getContextPath() + "/jsp/login.jsp"
        );
    }

    @Override
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        String email = request.getParameter("email");
        String password = request.getParameter("password");

        String sql = "SELECT * FROM user WHERE email=? AND password=?";

        try (Connection con = DBConnection.getConnection()) {

            if (con == null) {
                response.getWriter().println("Database connection failed!");
                return;
            }

            try (PreparedStatement ps = con.prepareStatement(sql)) {

                ps.setString(1, email);
                ps.setString(2, password);

                try (ResultSet rs = ps.executeQuery()) {

                    if (rs.next()) {

                        HttpSession session = request.getSession();

                        session.setAttribute("user_id", rs.getInt("user_id"));
                        session.setAttribute("full_name", rs.getString("full_name"));
                        session.setAttribute("email", email);
                        session.setAttribute("role", rs.getString("role"));

                        response.sendRedirect(
                            request.getContextPath() + "/jsp/dashboard.jsp"
                        );

                    } else {
                        response.sendRedirect(
                            request.getContextPath() + "/jsp/login.jsp?error=1"
                        );
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Login failed! Please try again.");
        }
    }
}
