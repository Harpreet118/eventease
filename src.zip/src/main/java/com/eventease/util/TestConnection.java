
package com.eventease.util;

import java.sql.Connection;

public class TestConnection {

    public static void main(String[] args) {

        Connection con = DBConnection.getConnection();

        if (con != null) {
            System.out.println("EventEase Database Connected!");
        } else {
            System.out.println("Database Connection Failed!");
        }

    }
}
